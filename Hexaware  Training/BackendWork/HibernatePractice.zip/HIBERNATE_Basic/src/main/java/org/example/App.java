package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    static SessionFactory factory;
    static Session session;
    App(){
        factory = new Configuration().configure("config.xml").addAnnotatedClass(Student.class).buildSessionFactory();
    }
    void addData(int roll, double newFee, String name) {

        session = factory.openSession();

        Transaction tran = session.beginTransaction();
        Student s = new Student();
        s.setRoll(roll);
        s.setName(name);
        s.setFee(newFee);
        if (session.find(Student.class, roll) != null) {
            System.out.println("Duplicate entry for Student: " + s.getRoll());
        } else {

            session.save(s);
            tran.commit();
            System.out.println("Data Saved!");
        }
    }

    static void removeData(int rn){
        session = factory.openSession();
        Transaction transaction = session.beginTransaction();
//        Student student = session.find(Student.class,Roll);
//
//        if (student!= null){
//            session.delete(student);
//            transaction.commit();
//            System.out.println("Removed");
//        }
//        else{
//            System.out.println("Not Found");
//        }
        String sql="delete from Student where roll=:rn ";
        
        Query q = session.createQuery(sql);
        q.setParameter("rn",rn);
        int c=q.executeUpdate();
        transaction.commit();
        if(c>0)
        {
        	System.out.println("Removed");
        }
        else
        {
        	System.out.println(" Not Removed");
        }
        
    }

    void updateFee(int rn,double fees){
        session = factory.openSession();
        Transaction transaction = session.beginTransaction();
//        Student student = session.find(Student.class,roll);
//
//        if(student != null){
//            student.setFee(fee);
//            session.saveOrUpdate(student);
//            transaction.commit();
//            System.out.println("Updated Fee");
//        }
//        else{
//            System.out.println("Not Found");
//        }
String sql="Update Student set fee=:fees where roll=:rn";
        
        Query q = session.createQuery(sql);
        q.setParameter("fees",fees);
        q.setParameter("rn",rn);
        int c=q.executeUpdate();
        transaction.commit();
        if(c>0)
        {
        	System.out.println("Updated");
        }
        else
        {
        	System.out.println(" Not Updated");
        }
        
    }

    void increaseFee(int roll, double fee){
        session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Student student = session.find(Student.class,roll);

        if(student != null){
            double f = student.getFee();
            f+= fee;
            student.setFee(f);
            session.saveOrUpdate(student);
            transaction.commit();
            System.out.println("Increased Fee");
        }
        else{
            System.out.println("Not Found");
        }
    }

    void show(int pn,int ps){
        session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        
      //remember the double quotes placement in native query line
        Query<Student> query= session.createNativeQuery("Select * from Student",Student.class);
        
        //////
       // Query<Student> query= session.createQuery("From Student");
        //Paging
        //query.setFirstResult((pn-1)*ps);
        //the value in bracket is excluded and it shows records from ahead of it
        //query.setMaxResults(ps);
        //it is the max no of records to show to show
        
        List<Student>list = query.list();
        for(Student s: list){
            System.out.println(s.toString());
        }
    }

    void searchRollName(int rn,String nm){
        session = factory.openSession();
        Transaction tax = null;

        try {
            tax = session.beginTransaction();

            Query<Student> q = session.createQuery(
                    "from Student where roll = :rn and name = :nm",
                    Student.class
            );
            q.setParameter("rn", rn);
            q.setParameter("nm", nm);

            List<Student> list = q.list();

            for (Student s : list) {
                System.out.println(s.toString());
            }

            tax.commit();
        } catch (Exception e) {
            if (tax != null) tax.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }

    }

    void searchFeeRange(double left,double right){
        session = factory.openSession();
        Transaction tax = null;

        try {
            tax = session.beginTransaction();

            Query<Student> q = session.createQuery(
                    "from Student where fee > :left and fee < :right",
                    Student.class
            );
            q.setParameter("left", left);
            q.setParameter("right", right);

            List<Student> list = q.list();
            System.out.print("Result: ");
            for (Student s : list) {
                System.out.println(s.toString());
            }

            tax.commit();
        } catch (Exception e) {
            if (tax != null) tax.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }

    }

    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        App app = new App();
        //app.addData(101,2000.00,"Adarsh");
//        app.addData(102,2000.00,"Sam");
//        app.addData(103,3000.00,"Neil");
//        app.addData(104,6000.00,"Aman");
//        app.addData(105,5000.00,"Maan");
//        app.addData(106,2500.00,"Annie");
//        app.addData(107,4500.00,"Jasmine");
//        app.addData(108,8000.00,"Charmi");
//        app.addData(109,1500.00,"Dikshant");
//        app.addData(110,1000.00,"Durlabh");
//        app.addData(111,7000.00,"Raj");
        //App.removeData(101);
        //app.updateFee(101,1000.00);
        //app.increaseFee(101,1000.00);
        app.show(2,10);
        //app.searchRollName(101,"Amit");
        //app.searchFeeRange(1000.00,3000.00);

    }
}
