package org.example;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Student {
    @Id
    @Column
    private int Roll;
    @Column
    private String Name;
    @Column
    private double Fee;

    public int getRoll() {
        return Roll;
    }

    public void setRoll(int roll) {
        this.Roll = roll;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public double getFee() {
        return Fee;
    }

    public void setFee(double fee) {
        this.Fee = fee;
    }

    public Student(){}

    public Student(int roll, String name, double fee) {
        this.Roll = roll;
        this.Name = name;
        this.Fee = fee;
    }

    @Override
    public String toString() {
        return "Student{" +
                "Roll=" + Roll +
                ", Name='" + Name + '\'' +
                ", Fee=" + Fee +
                '}';
    }
}
