package com.hexa.crud.boot.BankService;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.crud.boot.BankRepo.BankRepo;
import com.hexa.crud.boot.Customer.Customer;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
public class BankService {

	@Autowired
	BankRepo rep;
	
	public Customer saveData(Customer c)
	{
		Customer cser= rep.save(c);
		return cser;
	}
	
	public List show()
	{
		List l=rep.findAll();
		return l;
	}
	
	public Customer getDataId(int ac)
	{
		Customer r=rep.findById(ac).orElse(null);
		
		return r;
	}

	public String removeData(int ac) {
		
		rep.deleteById(ac);
		return "Removed";
	}
	public String updateData(int ac, double fe) {
		
		
		Customer cus=   rep.findById(ac).orElse(null);
		if(cus==null)
			return "Cannot update";
	     cus.setFee(fe);
	     rep.save(cus);
		
		
		return "updated";
	}

	public String depositData(int ac, double fe) {
	    Customer cus = rep.findById(ac).orElse(null);
	    if (cus == null) {
	        return "User  does not exist";
	    }

	    
	    double currentFee = cus.getFee();
	    cus.setFee(currentFee + fe); 
	    rep.save(cus);

	    return "Fee deposited successfully";
	}
	
	public String withdrawData(int ac, double fe) {
	    Customer cus = rep.findById(ac).orElse(null);
	    if (cus == null) {
	        return "User  does not exist";
	    }

	    double currentFee = cus.getFee();
	    if (currentFee < fe) {
	        return "Insufficient balance";
	    }

	    cus.setFee(currentFee - fe); 
	    rep.save(cus);

	    return "Fee withdrawn successfully";
	}
	
	
	public  List<Customer> getUsersWithLowFees() {
        return rep.findByFeeLessThan(5500);
	}

	public List<Customer> getUsersWithMoreFees() {
		return rep.findByFeeGreaterThan(5500);
	}

//	public List<Customer> findCustomersByNameAndCity(String name, String city) {
//        return rep.getUsersByDept(name, city);
//    }

	
	public List<Customer> findAll() {
		return rep.findallcustomer();
	}

	@Transactional
	 public void updateCustomerName(String name, int actno) {
	        rep.updateCustomerName(name, actno);
	    }
	public String deletecustomer(int actno) {
		 int r=rep.deleteByActno(actno);
		 return r>0?"Deleted succesfully":"Customer not found";
	 }
//11th November 2024
	public String removeDataRE(int ac) {
		Customer cus=rep.findById(ac).orElse(null);
		if(cus==null)
			return "Already not present";
	   	
			rep.deleteById(ac);
			return "Removed";
		}
	public Customer getCustomerRE(int ac) {
        return rep.findById(ac).orElse(null); // Return Customer or null if not found
    }
	public int countEL() {
        return rep.countEL();
    }


	
    public List<Customer> getEligibleCustomersByFee() {
        List<Customer> allCustomers = rep.findallcustomer();
        List<Customer> eligibleCustomers = allCustomers.stream()
                .filter(customer -> customer.getFee() > 10000)
                .collect(Collectors.toList());
        if(eligibleCustomers.isEmpty())
        	return null;
        return eligibleCustomers;
            }
//	public List<String> getEligibleCustomerNames() { // Renamed for clarity
//  List<Customer> eligibleCustomers = rep.findEligibleCustomers(); 
//  return eligibleCustomers.stream() 
//          .map(Customer::getName) 
//          .collect(Collectors.toList());
//}
	
//	public List<Customer> getUsersWithEndName() {
//		return rep.findByFirstnameEndingWith("a");
//	}
//
//	public List<Customer> getUsersWithNotName() {
//		return rep.findByFirstnameNotLike("Z");
//	}
	//12th November 2024
    public boolean existsByActno(int actno) {
        return rep.existsById(actno); 
    }
	
}
