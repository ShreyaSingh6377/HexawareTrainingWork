package com.hexa.crud.boot.CustomException;

public class DuplicateCustomerException extends RuntimeException {
    private final int actNo;

    public DuplicateCustomerException(String message, int actNo) {
        super(message + " for account number: " + actNo);
        this.actNo = actNo;
    }

    public int getActNo() {
        return actNo;
    }
}
