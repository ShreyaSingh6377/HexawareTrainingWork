package com.hexa.crud.boot.Customer;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
public class Customer {
	@Id
	int actno;
	
	@NotBlank(message = "Name is mandatory")
	@Pattern(regexp = "^[A-Za-z\\s]{1,20}$", message = "Name must be between 1 and 20 alphabetic characters and may include spaces.")
	String name;
	double fee;
//	String city;
//	public String getCity() {
//		return city;
//	}
//	public void setCity(String city) {
//		this.city = city;
//	}
	public int getActno() {
		return actno;
	}
	public void setActno(int actno) {
		this.actno = actno;
	}
	@Override
	public String toString() {
		return "Customer [actno=" + actno + ", name=" + name + ", fee=" + fee + "]";
	}
	public String getName() {
		return name;
	}
	public Customer() {
		
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
//	public Customer(int actno, String name, double fee, String city) {
//		super();
//		this.actno = actno;
//		this.name = name;
//		this.fee = fee;
//		this.city = city;
//	}
//	@Override
//	public String toString() {
//		return "Customer [actno=" + actno + ", name=" + name + ", fee=" + fee + ", city=" + city + "]";
//	}
	public double getFee() {
		return fee;
	}
	public Customer(int actno,
		@NotBlank(message = "Name is mandatory") @Pattern(regexp = "^[A-Za-z\\s]{1,20}$", message = "Name must be between 1 and 20 alphabetic characters and may include spaces.") String name,
		double fee) {
	super();
	this.actno = actno;
	this.name = name;
	this.fee = fee;
}
	public void setFee(double fee) {
		this.fee = fee;
	}

}
