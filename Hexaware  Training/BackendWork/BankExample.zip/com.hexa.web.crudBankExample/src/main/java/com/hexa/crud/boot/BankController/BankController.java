package com.hexa.crud.boot.BankController;


import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.hexa.crud.boot.BankRepo.CustomerDTO;
import com.hexa.crud.boot.BankService.BankService;
import com.hexa.crud.boot.Customer.Customer;
import com.hexa.crud.boot.CustomException.DuplicateCustomerException;
import com.hexa.crud.boot.CustomException.InvalidInputException;
import com.hexa.crud.boot.CustomException.NoCustomerFoundException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class BankController {
	
	@Autowired
	BankService ser;
	
//commented cause of dto object downwards
//	@PostMapping("/saveData")
//	public Customer saveD(@RequestBody Customer c)
//	{
//		Customer r=ser.saveData(c);
//		return r;
//	}
	
	
	@GetMapping("/getAll")
	public  List <Customer> getData()
	{
		List l=ser.show();
		return l;
	}
	
	
	@GetMapping("/getId/{ac}")
	public Customer getbyId(@PathVariable int ac)
	{
		Customer r=ser.getDataId(ac);
		return r;
	}
	
	@DeleteMapping("/remove/{ac}")
	public String removeData(@PathVariable int ac)
	{
		String r=ser.removeData(ac);
		return r;
	}
	
	@PutMapping("/updateFee/{ac}/{fe}")
	   public String updateFee(@PathVariable int ac, @PathVariable double  fe)
	   {
		   
		 String r=  ser.updateData(ac,fe);
		 return r;
	   }
	//take ac and balance ,create endpoint deposit 
	@PutMapping("/depositFee/{ac}/{fe}")
	public String depositFee(@PathVariable int ac, @PathVariable double fe) {
	    String result = ser.depositData(ac, fe);
	    return result;
	}
	
	@PutMapping("/withdrawFee/{ac}/{fe}")
	public String withdrawFee(@PathVariable int ac, @PathVariable double fe) {
	    String result = ser.withdrawData(ac, fe);
	    return result;
	}
	
	@GetMapping("/lowFees")
    public List<Customer> getUsersWithFeesLessThan() {
        return ser.getUsersWithLowFees(); 
    }
	
	@GetMapping("/greaterFees")
    public List<Customer> getUsersWithFeesMoreThan() {
        return ser.getUsersWithMoreFees(); 
    }
	
//	@GetMapping("/search")
//    public List<Customer> searchCustomers(@RequestParam String name, @RequestParam String city) {
//        return ser.findCustomersByNameAndCity(name, city);
//    }
//	
//	@GetMapping("/searchByNative")
//    public List<Customer> findAll() {
//        return ser.findAll();
//    }
	
	 @PutMapping("/updateName/{name}/{actno}")
	    public void updateCustomer( @PathVariable String name,@PathVariable int actno) {
	       ser.updateCustomerName(name, actno);
	    }
	
	 
	 @DeleteMapping("/deletec/{actno}")
	    public String deleteCustomer(@PathVariable int actno) {
	        return ser.deletecustomer(actno);
	    }
	 
	 @PostMapping("/users")
	    ResponseEntity<String> addUser(@Valid @RequestBody Customer user) {
	        // persisting the user
	        return ResponseEntity.ok("User is valid");
	    }
	
	 @PostMapping("/persons")
	    public ResponseEntity<String> addPerson(@Valid @RequestBody Customer person) {
	        
	        return ResponseEntity.ok("Person is valid: " + person.getName());
	    }
	 
	 //11th November 2024
	 @PostMapping("/saveDataRE")
	 public ResponseEntity<Customer> save(@Valid @RequestBody Customer c)
	 {
		 Customer r= ser.saveData(c);
		   
		   return new ResponseEntity<>(r,HttpStatus.CREATED);
	 }
	 
	 @GetMapping("/getAllRE")
	 public ResponseEntity<List<Customer>> getDataByRE()
	 {
		 List l=ser.show();
		 if(l.isEmpty())
		 {
			 return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		 }
		 return new ResponseEntity<>(l,HttpStatus.OK);
	 }
	 
	 @PutMapping("/updateFeeRE/{ac}/{fe}")
	   public ResponseEntity<String> updateFeeRE(@PathVariable int ac, @PathVariable double  fe)
	   {
		   
		 String r=  ser.updateData(ac,fe);
		 if(r.equals("updated"))
		 {
			 return new ResponseEntity<>(r,HttpStatus.OK);
		 }
		 return new ResponseEntity<>("not updated",HttpStatus.NOT_FOUND);
	   }
	 
	 @DeleteMapping("/removeRE/{ac}")
		public ResponseEntity<String> removeDataRE(@PathVariable int ac)
		{
			String r=ser.removeDataRE(ac);
			if(r.equals("Removed"))
			 {
				 return new ResponseEntity<>(r,HttpStatus.OK);
			 }
			 return new ResponseEntity<>("Not removed",HttpStatus.NOT_FOUND);
		}
	 @GetMapping("/getCustomerRE/{ac}")
	    public ResponseEntity<Customer> getCustomerById(@PathVariable int ac) {
	        Customer customer = ser.getCustomerRE(ac);
	        if (customer == null) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	        return new ResponseEntity<>(customer, HttpStatus.OK);
	    }
	 @GetMapping("/countEligibleCustomers")
	    public ResponseEntity <Integer>countEL(){
	        int count = ser.countEL();
	        return new ResponseEntity<>(count, HttpStatus.OK); 
	 }
	 

	 @GetMapping("/displayEligibleCustomer")
	    public ResponseEntity<List<Customer>> displayEligibleCustomer() {
	        List<Customer> eligibleCustomers = ser.getEligibleCustomersByFee();
	        
	        if (eligibleCustomers == null) {
	            return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	        } else {
	            return new ResponseEntity<>(eligibleCustomers, HttpStatus.OK); 
	        }
	 } 


	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
		/*CustomerDTO  maptoDTO(Customer c)
		{
			
		   
		   return new  CustomerDTO(c.getActno(),c.getName(),c.getFee());
		}
		
		
		Customer  mapToEntity(CustomerDTO c)
		{
		   return new Customer(c.getActno(),c.getName(),c.getFee());
		}*/
		
//		@PostMapping("/saveDataByDTO")
//		   public  ResponseEntity< CustomerDTO>saveD(@Valid @RequestBody CustomerDTO c)
//		   {
//			   
//			   Customer d=  mapToEntity(c);
//			   
//			   Customer r= ser.saveData(d);
//			   CustomerDTO t=maptoDTO(r);
//			   
//			   return new ResponseEntity<>(t,HttpStatus.CREATED);
//			   
//		   }
//		@GetMapping("/getIdByDTO/{ac}")
//	    public ResponseEntity<CustomerDTO> getById(@PathVariable int ac) {
//	        Customer customer = ser.getDataId(ac);
//	        if (customer == null) {
//	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Return 404 if not found
//	        }
//	        CustomerDTO customerDTO = maptoDTO(customer); // Map to DTO
//	        return new ResponseEntity<>(customerDTO, HttpStatus.OK); // Return DTO with 200 OK
//	    }
//		@GetMapping("/getAllByDTO")
//		public ResponseEntity<List <CustomerDTO>> getDatabyDTO()
//		{
//			List<Customer> l=ser.show();
//			List<CustomerDTO>users=new ArrayList<>();
//			for(Customer i:l)
//			{
//				CustomerDTO t=maptoDTO(i);
//				users.add(t);
//			}
//			if(l.isEmpty())
//			 {
//				 return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
//			 }
			
			
//			return new ResponseEntity<>(users,HttpStatus.OK);
//			
//		}
		
//		@GetMapping("/getIdCheck/{ac}")
//		   public ResponseEntity<?> getByIdCheck(@PathVariable int ac) {
//		       try {
//		           Customer r = ser.getDataId(ac); // retrieve the customer data
//		           if (r == null) {
//		               return new ResponseEntity<>("Customer with account number " + ac + " not found.", HttpStatus.NOT_FOUND);
//		           }
//		           return new ResponseEntity<>(r, HttpStatus.OK); // return the retrieved customer 'r'
//		       } catch (Exception e) {
//		           return new ResponseEntity<>("An error occurred while retrieving customer data.", HttpStatus.INTERNAL_SERVER_ERROR);
//		       }
//		   }
		@GetMapping("/getIdCheck/{ac}")
		public ResponseEntity<?> getByIdCheck(@PathVariable int ac) throws NoCustomerFoundException {
		   //public ResponseEntity<?> getByIdCheck(@PathVariable int ac) {
			//commented to call global excpetion
		       /*try {
		           Customer r = ser.getDataId(ac);
		           if (r == null) {
		               
		               throw new NoCustomerFoundException("Customer with account number " + ac + " not found.");
		           }
		           return new ResponseEntity<>(r, HttpStatus.OK); 
		       } catch (NoCustomerFoundException e) {
		          
		           return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		       } catch (Exception e) {
		           
		           return new ResponseEntity<>("An error occurred while retrieving customer data.", HttpStatus.INTERNAL_SERVER_ERROR);
		       }*/
			//commented to get the message form global exception
			Customer r = ser.getDataId(ac);
		    if (r == null) {
		        throw new NoCustomerFoundException("Customer with account number " + ac + " not found.");
		    }
		    return new ResponseEntity<>(r, HttpStatus.OK);
		   }
		@DeleteMapping("/deleteCheck/{actno}")
	    public ResponseEntity<?> deleteCustomerCheck(@PathVariable int actno) {
	        try {
	            String response = ser.deletecustomer(actno); 
	            if (response.equals("Customer not found")) {
	                return new ResponseEntity<>("Customer with account number " + actno + " not found.", HttpStatus.NOT_FOUND);
	            }
	            return new ResponseEntity<>("Customer with account number " + actno + " has been deleted successfully.", HttpStatus.OK);
	        } catch (Exception e) {
	            return new ResponseEntity<>("An error occurred while deleting the customer.", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
		 /*@PostMapping("/saveDataCheck")
		    public ResponseEntity<?> saveDataCheck(@RequestBody Customer c) {
		        try {
		            if (c.getActno() <= 0) { 
		                throw new InvalidInputException("Account number must be positive.", c.getActno());
		            }
		            if (c.getFee() < 0) { 
		                throw new InvalidInputException("Fee cannot be negative.", c.getActno());
		            }
		            if (c.getName() == null || c.getName().isEmpty()) { 
		                throw new InvalidInputException("Customer name cannot be null or empty.", c.getActno());
		            }

		            Customer savedCustomer = ser.saveData(c);
		            return new ResponseEntity<>(savedCustomer, HttpStatus.CREATED);
		        } catch (InvalidInputException ex) {
		            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
		        }
		    }*/
		@PostMapping("/saveDataCheck")
		public ResponseEntity<?> saveDataCheck(@RequestBody Customer c) throws InvalidInputException {
		    
		    if (c.getActno() <= 0) {
		        throw new InvalidInputException("Account number must be positive.", c.getActno());
		    }
		    if (c.getFee() < 0) {
		        throw new InvalidInputException("Fee cannot be negative.", c.getActno());
		    }
		    if (c.getName() == null || c.getName().isEmpty()) {
		        throw new InvalidInputException("Customer name cannot be null or empty.", c.getActno());
		    }

		    Customer savedCustomer = ser.saveData(c);
		    return new ResponseEntity<>(savedCustomer, HttpStatus.CREATED);
		}
		 @Autowired
		   ModelMapper model;
		   @PostMapping("/saveData")
		   public ResponseEntity<CustomerDTO> saveDataMapper(@Valid @RequestBody CustomerDTO c) {
			   
			    Customer d = model.map(c, Customer.class);
			    
			   
			    Customer r = ser.saveData(d);
			    
			   
			    if (r == null) {
			        throw new RuntimeException("Customer could not be saved. Account number: " + c.getActno());
			    }
			    
			    
			    CustomerDTO t = model.map(r, CustomerDTO.class);
			    
			    
			    return new ResponseEntity<>(t, HttpStatus.CREATED);
			}
		   
		   //12th November
		   @PostMapping("/saveDataCheckByCustomException")
		   public ResponseEntity<?> saveDataCheck(@Valid @RequestBody CustomerDTO c) {
		       try {
		           if (ser.existsByActno(c.getActno())) {
		               throw new DuplicateCustomerException("Customer already exists", c.getActno());
		           }

		           
		           Customer d = model.map(c, Customer.class);
		           Customer savedCustomer = ser.saveData(d);

		           return new ResponseEntity<>(savedCustomer, HttpStatus.CREATED);
		       } catch (DuplicateCustomerException ex) {
		           return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
		       } catch (Exception ex) {
		           return new ResponseEntity<>("An unexpected error occurred.", HttpStatus.INTERNAL_SERVER_ERROR);
		       }
		   }
}	



