package com.hexa.crud.boot.CustomException;

public class InvalidInputException extends Exception{
	int actNo;

    public InvalidInputException(String message, int i) {
        super(message + " for account number: " + i);
        this.actNo = i;
    }

    

    public int getActNo() {
        return actNo;
    }
}

