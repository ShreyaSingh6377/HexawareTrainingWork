package com.hexa.crud.boot.CustomException;

public class NoCustomerFoundException extends Exception{
	
	String msg;
	
	public NoCustomerFoundException(String msg)
	{
		super(msg);
		this.msg=msg;
	}

public String getMessage()
{
	return msg;
}
}
