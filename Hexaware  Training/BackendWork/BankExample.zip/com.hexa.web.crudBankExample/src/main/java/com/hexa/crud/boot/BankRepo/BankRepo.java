package com.hexa.crud.boot.BankRepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hexa.crud.boot.Customer.Customer;

import jakarta.transaction.Transactional;

@Repository
public interface BankRepo extends JpaRepository<Customer,Integer>{

	
	 List<Customer> findByFeeLessThan(double fee);
	 List<Customer> findByFeeGreaterThan(double fee);
	 
	 //commented due to creation of dto object, if needed remove comments from all files containing city field 
//     @Query("select u from Customer u where u.name=:nm and city=:ct")
//	 public  List<Customer>getUsersByDept( @Param("nm")String name,  @Param("ct")String city);
	 
     @Query(value = "select * from customer",nativeQuery=true)
     public  List<Customer>findallcustomer();
     
     @Modifying
     @Query(value = "UPDATE customer c SET c.name = ?1 WHERE c.actno = ?2", nativeQuery = true)
     public void updateCustomerName(String name, int actno);
     
     @Modifying
     @Transactional
     @Query(value = "DELETE FROM customer WHERE actno = :ac", nativeQuery = true)
     int deleteByActno(int ac);
     
     
     //11th November 2024
     @Query(value="Select count(*) from customer where fee>10000",nativeQuery = true)
     int countEL();
     
//     @Query(value = "SELECT * FROM customers WHERE fee > 10000", nativeQuery = true)
//     List<Customer> findEligibleCustomers();

}
