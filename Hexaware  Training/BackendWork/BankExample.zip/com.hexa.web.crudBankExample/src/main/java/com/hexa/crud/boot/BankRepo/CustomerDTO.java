package com.hexa.crud.boot.BankRepo;

public class CustomerDTO {
int actno;

String name;
double fee;
public int getActno() {
	return actno;
}
public void setActno(int actno) {
	this.actno = actno;
}
public double getFee() {
	return fee;
}
public void setFee(double fee) {
	this.fee = fee;
}
public String getName() {
	return name;
}
public CustomerDTO() {
}

@Override
public String toString() {
	return "CustomerDTO [actno=" + actno + ", name=" + name + ", fee=" + fee + "]";
}
public void setName(String name) {
	this.name = name;
}
public CustomerDTO(int actno, String name, double fee) {
	super();
	this.actno = actno;
	this.name = name;
	this.fee = fee;
}


}
