package com.hexaware.onetoone.com.hexaware.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class Student {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "roll")
    private int roll;
	
	@Column
	String name;
	
	@Override
	public String toString() {
		return "Student [roll=" + roll + ", name=" + name + ", result=" + result + "]";
	}

	public Student(int roll, String name, Result result) {
		super();
		this.roll = roll;
		this.name = name;
		this.result = result;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Result")
    private Result result;
	

}
