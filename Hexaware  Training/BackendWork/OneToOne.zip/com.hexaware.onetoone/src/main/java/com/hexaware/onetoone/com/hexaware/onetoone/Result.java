package com.hexaware.onetoone.com.hexaware.onetoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Result")
public class Result {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rid")
    private int rid;
	
	@Column
	private int marks;
	
	@Column
	private String sub;

	@Override
	public String toString() {
		return "Result [rid=" + rid + ", marks=" + marks + ", sub=" + sub + "]";
	}

	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Result(int rid, int marks, String sub) {
		super();
		this.rid = rid;
		this.marks = marks;
		this.sub = sub;
	}

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getSub() {
		return sub;
	}

	public void setSub(String sub) {
		this.sub = sub;
	}

}
