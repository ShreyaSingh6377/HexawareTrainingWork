package com.hexaware.onetoone.com.hexaware.onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory fac;
    	Session sess;
    	
    	
        fac = new Configuration().configure("hiber.config.xml")
                    .addAnnotatedClass(Student.class)
                    .buildSessionFactory();
    	
	    sess = fac.openSession();
		
        Transaction tax = sess.beginTransaction();
        Result r1=new Result();
        //r1.setRid(105);not needed as auto generated
        r1.setMarks(95);
        
        r1.setSub("Commerce");
        sess.save(r1);
        Student s = new Student();
       // s.setRoll(5); not needed as auto generated
        s.setName("Sayi");
        s.setResult(r1);
        sess.save(s);
        tax.commit(); // Commit the transaction to save changes

        sess.close();
        fac.close();
    }
}
