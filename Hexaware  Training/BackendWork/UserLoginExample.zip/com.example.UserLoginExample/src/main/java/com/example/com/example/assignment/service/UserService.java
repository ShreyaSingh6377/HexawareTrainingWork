package com.example.com.example.assignment.service;




import org.springframework.stereotype.Service;

import com.example.com.example.assignment.model.Login;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private List<Login> users = new ArrayList<>();

    public String signUp(Login login) {
        if (users.stream().anyMatch(user -> user.getUid().equals(login.getUid()))) {
            return "User  already exists!";
        }
        users.add(login);
        return "User  signed up successfully!";
    }

    public String signIn(String uid, String password) {
        Optional<Login> user = users.stream()
                .filter(u -> u.getUid().equals(uid) && u.getPassword().equals(password))
                .findFirst();
        return user.isPresent() ? "Sign in successful!" : "Invalid credentials!";
    }

    public String updatePassword(String uid, String newPassword) {
        for (Login user : users) {
            if (user.getUid().equals(uid)) {
                user.setPassword(newPassword);
                return "Password updated successfully!";
            }
        }
        return "User  not found!";
    }

    public String removeAccount(String uid) {
        if (users.removeIf(user -> user.getUid().equals(uid))) {
            return "Account removed successfully!";
        }
        return "User  not found!";
    }
}