package com.example.com.example.assignment.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.com.example.assignment.model.Login;
import com.example.com.example.assignment.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/signup")
    public String signUp(@RequestBody Login login) {
        return userService.signUp(login);
    }

    @PostMapping("/signin")
    public String signIn(@RequestParam String uid, @RequestParam String password) {
        return userService.signIn(uid, password);
    }

    @PutMapping("/update-password")
    public String updatePassword(@RequestParam String uid, @RequestParam String newPassword) {
        return userService.updatePassword(uid, newPassword);
    }

    @DeleteMapping("/remove-account")
    public String removeAccount(@RequestParam String uid) {
        return userService.removeAccount(uid);
    }
}
