package com.hexaware.logapp.com.hexaware.logapps;




import java.util.Scanner;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.hibernate.query.Query;





/**
 * Hello world!
 *
 */
public class App 
{
	
	static SessionFactory fac;
	Session ses;
	App()
	{
		
		fac= new Configuration().configure("hiber.config.xml").
			addAnnotatedClass(Credential.class).buildSessionFactory();
	
	}
	
	boolean checkUser(String username) {
        Session ses = fac.openSession();
        Credential c = ses.find(Credential.class, username);
        ses.close();
        return c != null;
    }
	void signUp()
	{
		String u;
		Scanner sc=new Scanner(System.in);
		 System.out.println("Enter username:");
		 u=sc.nextLine();
	        if (checkUser(u)) {
	            System.out.println("Duplicate entry " + u + " already exists.");
	            return;
	        }

	        Session ses = fac.openSession();
	        Transaction tax = ses.beginTransaction();

	        String p;
	        String e;
	        System.out.println("Enter password:");
			 p=sc.nextLine();
			 System.out.println("Enter email:");
			 e=sc.nextLine();
	        Credential c = new Credential();
	        c.setUsername(u);
	        c.setPassword(p);
	        c.setEmail(e);
	        c.setStatus(true); //here we are setting up the status to true 
	        
	        ses.save(c);
	        tax.commit();
	        
	        System.out.println("Data saved.");
	        ses.close();
	       
	}
	boolean checkPassword(String username,String password) {
		if (checkUser(username))
				{
		Session ses = fac.openSession();        
		Credential c = ses.find(Credential.class, username);
        String p=c.getPassword();
        if( p.equals(password) ) 
        {
        	ses.close();
        	return true;
        }
				}
		System.out.println("Incorrect credentials");
		return false;
        
    }
	void signIn()
	{
		String u;
		String p;
		Scanner sc=new Scanner(System.in);
		 System.out.println("Enter username:");
		 u=sc.nextLine();
		 System.out.println("Enter password:");
		 p=sc.nextLine();
	        if ( checkPassword(u,p)) {
	        System.out.println("Login Successful");
	       
	        }
	        else {
	        	System.out.println("Login not successful");
	        }        
	        
	}
	void updateCredential()
	{
		String u;
		String p;
		
		Scanner sc=new Scanner(System.in);
		 System.out.println("Enter username:");
		 u=sc.nextLine();
		 System.out.println("Enter password:");
		 p=sc.nextLine();
		 if ( checkPassword(u,p)) {
		        System.out.println("Login Successful");
		       
		        }
		        else {
		        	System.out.println("Login not successful");
		        	return ;
		        }
		      System.out.println("Now you can change the password");
		      String np;
		      System.out.println(" Enter the new password");
		      np=sc.nextLine();
		      
		      Session ses = fac.openSession();
		      Transaction tax = ses.beginTransaction();
		      Credential c = ses.find(Credential.class, u);
		      c.setPassword(np);
		      
		      System.out.println("Password updated successfully");
		      //c.setStatus(true);
		      
		      ses.save(c);
		      tax.commit();
	}
	void closeAccount()
	{
		String u;
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter username to close account:");
	    u = sc.nextLine();

	    
	    if (!checkUser (u)) {
	        System.out.println("User  " + u + " does not exist.");
	        return;
	    }
	    
	    
	    String p;
	    System.out.println("Enter password:");
	    p = sc.nextLine();
	    
	    if (!checkPassword (u,p)) {
	        System.out.println("Password is wrong");
	        return;
	    }
	    
//	    Session ses = fac.openSession(); 
//	    Transaction tx = ses.beginTransaction(); 
//
//	    Credential c = ses.find(Credential.class, u);
//	    if (c != null ) {
//	    	
//	        ses.delete(c); 
//	        tx.commit();
//	        System.out.println("Account for " + u + " has been closed.");
//	    
//	    }
	    ////hql query here and in deactivate method;remember use class name in sql query not table name in database
	    Session ses = fac.openSession(); 
	    Transaction tx = ses.beginTransaction(); 
	    String sql="delete from Credential where username=:u ";
        
        Query q = ses.createQuery(sql);
        q.setParameter("u",u);
        int c=q.executeUpdate();
        tx.commit();
        if(c>0)
        {
        	System.out.println("Removed");
        }
        else
        {
        	System.out.println(" Not Removed");
        }

	    ses.close();
	    	
		
	}
	void deactivateAccount()
	{
		String u;
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter username to deactivate:");
	    u = sc.nextLine();    

	    
	    if (!checkUser (u)) {
	        System.out.println("User  " + u + " does not exist.");
	        return;
	    }
	    
	    

	    String p;
	    System.out.println("Enter password:");
	    p = sc.nextLine();
	    
	    if (!checkPassword (u,p)) {
	        System.out.println("Password is wrong");
	        return;
	    }
	    
	    Session ses = fac.openSession(); 
	    Transaction tx = ses.beginTransaction(); 
	    Credential c = ses.find(Credential.class, u);
	    if (c != null ) {
	    	if(c.isStatus()) {
	    		boolean s=false;
	    		String sql="Update Credential set status=:s where username=:u";
	            
	            Query q = ses.createQuery(sql);
	            q.setParameter("s",s);
	            q.setParameter("u",u);
	            int r=q.executeUpdate();
	            tx.commit();
	            if(r>0)
	            {
	            	System.out.println("Updated");
	            }
	            else
	            {
	            	System.out.println(" Not Updated");
	            }
	        //c.setStatus(false); 
	        tx.commit();
	        System.out.println("Account for " + u + " has been deactivated.");
	    }
	    }

	    ses.close();
	    	
		
	}
    public static void main( String[] args )
    {
    	App app= new App();
    	Scanner sc=new Scanner(System.in);
    	int ch=0;
    	while(true) {
        System.out.println( "----Main Menu----" );
        System.out.println("1.Sign up with username, password, and email");
        System.out.println("2.Sign in with username and password.");
        System.out.println("3.Update password once logged in.");
        System.out.println("4.Deactivate account");
        System.out.println("5.Close account");
        System.out.println("6.Exit");
        System.out.println("Enter your choice:");
        ch=sc.nextInt();
        switch(ch)
        {
        case 1:
        	app.signUp();
        	break;
        case 2:
        	app.signIn();
        	break;
        case 3:
        	app.updateCredential();
        	break;
        case 4:
        	app.deactivateAccount();
        	break;
        case 5:
        	app.closeAccount();
        	break;
        case 6:
        	System.out.println("Exitting from Applcation");
        	System.exit(0);
        default:
        	System.out.println("Wrong Choice");
        	}
        
    	}
    }
}
