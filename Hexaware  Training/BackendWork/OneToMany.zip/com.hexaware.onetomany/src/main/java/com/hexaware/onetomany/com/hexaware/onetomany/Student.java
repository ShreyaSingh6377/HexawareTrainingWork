package com.hexaware.onetomany.com.hexaware.onetomany;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "STUDENT")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "roll")
    private int roll;

    @Column
    private String name;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Result> results = new ArrayList<>(); // Initialize the list

    
    public Student() {
        super();
    }

    
    public Student(int roll, String name) {
        super();
        this.roll = roll;
        this.name = name;
    }

    // Getters and Setters
    public int getRoll() {
        return roll;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

 
    public void addResult(Result result) {
        results.add(result);
        result.setStudent(this); 
    }

    @Override
    public String toString() {
        return "Student [roll=" + roll + ", name=" + name + ", results=" + results + "]";
    }
}