package com.hexaware.onetomany.com.hexaware.onetomany;



import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//    	SessionFactory fac;
//    	Session sess;
//    	
//    	
//        fac = new Configuration().configure("hiber.config.xml")
//                    .addAnnotatedClass(Student.class)
//                    .buildSessionFactory();
//    	
//	    sess = fac.openSession();
//		
//        Transaction tax = sess.beginTransaction();
//        Result r1=new Result(30,"dsa");
//        Result r2=new Result(80,"cpp");
//        Result r3=new Result(70,"java");
//        Result r4=new Result(20,"python");
//        List <Result> res=new ArrayList<Result>();
//        res.add(r1);
//        res.add(r2);
//        res.add(r3);
//        res.add(r4);
//        //sess.save(res);
//        
//        Student s = new Student();
//        s.setRoll(2);
//        s.setName("Sakshi");
//        s.setResults(res);
//        sess.save(s);
//        tax.commit(); // Commit the transaction to save changes
//
//        sess.close();
//        fac.close();
    	
    	 
        SessionFactory fac = new Configuration()
                .configure("hiber.config.xml") // Ensure your configuration file is correctly set up
                .addAnnotatedClass(Student.class)
                .addAnnotatedClass(Result.class)
                .buildSessionFactory();
        Session sess = fac.openSession();

        Transaction tax = sess.beginTransaction();
        Student s = new Student();
        s.setRoll(2);
        s.setName("Sakshi");
        Result r1 = new Result(30, "dsa");
        r1.setStudent(s); 
        Result r2 = new Result(80, "cpp");
        r2.setStudent(s); 
        Result r3 = new Result(70, "java");
        r3.setStudent(s);
        Result r4 = new Result(20, "python");
        r4.setStudent(s); 
        List<Result> res = new ArrayList<>();
        res.add(r1);
        res.add(r2);
        res.add(r3);
        res.add(r4);

        
        s.setResults(res); 
        sess.save(s);

        tax.commit();

        sess.close();
        fac.close();
    	
    }
}

