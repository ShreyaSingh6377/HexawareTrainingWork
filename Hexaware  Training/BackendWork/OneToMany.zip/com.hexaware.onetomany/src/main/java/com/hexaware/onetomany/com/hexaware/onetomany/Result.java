package com.hexaware.onetomany.com.hexaware.onetomany;

import javax.persistence.*;

@Entity
@Table(name = "Result")
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rid")
    private int rid;

    @Column
    private int marks;

    @Column
    private String sub;

    @ManyToOne
    @JoinColumn(name = "student_roll", nullable = false) // Foreign key column in Result table
    private Student student;

    
    public Result() {
        super();
    }

 
    public Result(int marks, String sub) {
        super();
        this.marks = marks;
        this.sub = sub;
    }

    // Getters and Setters
    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public String toString() {
        return "Result [rid=" + rid + ", marks=" + marks + ", sub=" + sub + "]";
    }
}