package com.hexaware.school.com.hexaware.schoolh;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.hibernate.query.Query;






/**
 * Hello world!
 *
 */
public class App 
{
	SessionFactory fac;
	Session ses;
	App()
	{
		
		fac= new Configuration().configure("hiber.config.xml").
			addAnnotatedClass(Student.class).buildSessionFactory();
	
	}
	
	
	void addData()
	{
		ses = fac.openSession();
	     
	     Transaction tax=ses.beginTransaction();
	     Student s= new Student();
	     s.setRollno(101);
	     s.setName("Shreya");
	      s.setFee(2000);
	      ses.save(s);
	      tax.commit();
	      System.out.println("Data saved");
	}
	void removeData(int roll)
	{
		ses= fac.openSession();
		
		Transaction tax= ses.beginTransaction();
			Student s=ses.find(Student.class,roll);
			if(s!=null)
			{
				ses.delete(s);
				tax.commit();
				System.out.println( "REmoved" );
			}
			else {
				System.out.println( "Not found" );
			}
	}
	
	void updateFee(int roll, double fe)
	{
		ses=fac.openSession();
		Transaction tax= ses.beginTransaction();
		Student s=ses.find(Student.class,roll);
		if(s!=null)
		{
			s.setFee(fe);
			//ses.save(s);
			ses.saveOrUpdate(s);
			tax.commit();
		}
	}
	void increaseFee(int roll, double fe)
	{
		ses=fac.openSession();
		Transaction tax= ses.beginTransaction();
		Student s=ses.find(Student.class,roll);
		if(s!=null)
		{
			double nf=s.getFee();
			s.setFee(fe+nf);
			//ses.save(s);
			ses.saveOrUpdate(s);
			tax.commit();
		}
	}
	
	void show()
	{
		ses=fac.openSession();
		Transaction tax= ses.beginTransaction();
		Query<Student> q = ses.createQuery("from Student");
		List <Student> sList = q.list();
		for(Student s: sList)
		{
			System.out.println(s.toString());
		}
		
		
	}
	boolean checkDuplicateEntry(int roll) {
        Session ses = fac.openSession();
        Student s = ses.find(Student.class, roll);
        ses.close();
        return s != null;
    }
	void checkDuplicateBeforeAdd()
	{
		 int rollNumber = 105;  // example roll number
	        if (checkDuplicateEntry(rollNumber)) {
	            System.out.println("Duplicate entry. Student with roll number " + rollNumber + " already exists.");
	            return;
	        }

	        Session ses = fac.openSession();
	        Transaction tax = ses.beginTransaction();

	        Student s = new Student();
	        s.setRollno(rollNumber);
	        s.setName("pooja");
	        s.setFee(2000);

	        ses.save(s);
	        tax.commit();

	        System.out.println("Data saved.");
	        ses.close();
//		int r;
//		Scanner sc = new Scanner(System.in);
//		System.out.println( "Enter roll no. to add:" );
//		r=sc.nextInt();
//		sc.nextLine();
//		ses=fac.openSession();
//		Transaction tax= ses.beginTransaction();
//		Query<Student> q = ses.createQuery("from Student");
//		List <Student> sList = q.list();
//		
//		for(Student s: sList)
//		{
//			if(r== s.getRollno())
//			{
//				String name;
//				Double f;
//				System.out.println( "Enter name:" );
//				name=sc.nextLine();
//				System.out.println( "Enter fee:" );
//				f=sc.nextDouble();
//				s.setRollno(r);
//			     s.setName(name);
//			      s.setFee(f);
//			      ses.save(s);
//			      tax.commit();
//			      System.out.println("Data saved");
//			}
//			else {
//				System.out.println("Duplicate Entry");
//			}
//			//System.out.println(s.toString());
//		}
	}
	
	
	void searchRollNo(int rn,String nm)
	{
		
		ses=fac.openSession();
		Transaction tax= ses.beginTransaction();
		Query <Student> q=ses.createQuery("from Student stud where stud.rollno=:rn and stud.name=:nm", Student.class);
		//Query<Student> q = ses.createQuery("from Student stud where stud.rollno=:rn and stud.name=:nm");
		q.setParameter("rn",rn);
		q.setParameter("nm",nm);
		List <Student> sList = q.list();
		for(Student s: sList)
		{
			System.out.println(s.toString());
		}
		
	}
	
	public void searchByFeeRange(double minFee, double maxFee) {
		ses=fac.openSession();
		Transaction tax= ses.beginTransaction();

            
            Query<Student> q = ses.createQuery("from Student stud where stud.fee between :minFee and :maxFee", Student.class);
            q.setParameter("minFee", minFee);
            q.setParameter("maxFee", maxFee);

            
            List<Student> sList = q.list();

            
            for (Student s : sList) {
                System.out.println(s.toString());
            }

            tax.commit(); 
        }
    public static void main( String[] args )
    {
//    	SessionFactory fac= new Configuration().configure("hiber.config.xml").
//    			addAnnotatedClass(Student.class).buildSessionFactory();
//    	//SessionFactory fac= new Configuration().configure("hiber.config.xml").addAnnotatedClass(Student.class);
//        System.out.println( "Hello World!" );
//        
//        Session ses= fac.openSession();
//	     
//	     Transaction tax=ses.beginTransaction();
//	     Student s= new Student();
//	     s.setRollno(101);
//	     s.setName("Ajay");
//	      s.setFee(2000);
//	      ses.save(s);
//	      tax.commit();
//	      System.out.println("Data saved");
    	
    	App app= new App();//do update in hiberconfig inplace of create to add another record with different id that's already there
    	
   	 	//app.addData();
//    	Scanner sc=new Scanner(System.in);
//    	System.out.println( "Enter roll no. to remove:" );
//    	int r=sc.nextInt();
//   	 	app.removeData(r);
    	
    	//app.updateFee(101,1000);
    	//app.increaseFee(101,4000);
//    	app.show();
//    	app.checkDuplicateBeforeAdd();
    	app.searchRollNo(105,"pooja");
    	//app.searchByFeeRange(100,2500);
    	System.out.println( "Hello World!" );
    	
    }
}
