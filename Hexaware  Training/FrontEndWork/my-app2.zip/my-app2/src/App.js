import React, { useEffect, useState } from "react";
import "./App.css";
import CardExampleCard from "./Card";
import MenuExamplePointing from "./Navbar";
import Modal from "./Modal";

function App() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    setFilteredProducts(
      products.filter((product) =>
        product.title.toLowerCase().includes(search.toLowerCase())
      )
    );
  }, [search, products]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((response) => response.json())
      .then((data) => setProducts(data))
      .catch((error) => console.error(error));
  }, []);

  const removeProduct = (id) => {
    setProducts(products.filter((product) => product.id !== id));
  };

  const addProduct = (newProduct) => {
    setProducts([newProduct, ...products]);
  };

  return (
    <>
      <MenuExamplePointing search={search} setSearch={setSearch} />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginTop: "40px",
          marginBottom: "20px",
        }}
      >
        <Modal onAddProduct={addProduct} />
      </div>
      <div className="container">
        {(search.length > 0 ? filteredProducts : products).map((product) => (
          <CardExampleCard
            key={product.id}
            id={product.id}
            image={product.image}
            title={product.title}
            price={product.price}
            description={product.description}
            rating={product.rating}
            removeProduct={removeProduct}
          />
        ))}
      </div>
    </>
  );
}

export default App;
