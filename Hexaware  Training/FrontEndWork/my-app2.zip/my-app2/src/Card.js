import React from "react";
import {
  CardMeta,
  CardHeader,
  CardDescription,
  CardContent,
  Card,
  Icon,
  Image,
} from "semantic-ui-react";
import "./App.css";
import ConfirmExampleConfirm from "./DeleteConfirm";
import { Button } from "semantic-ui-react";

const CardExampleCard = (props) => {
  const truncatedName = (name) => {
    return name.length > 20 ? name.slice(0, 20) + "..." : name;
  };

  const truncateDescription = (description) => {
    return description.length > 100
      ? description.slice(0, 100) + "..."
      : description;
  };

  return (
    <Card>
      <div className="card-image-container">
        <Image src={props.image} wrapped ui={false} />
      </div>
      <CardContent>
        <CardHeader>{truncatedName(props.title)}</CardHeader>
        <CardMeta>
          <span className="date">{props.price}</span>
        </CardMeta>
        <CardDescription>
          {truncateDescription(props.description)}
        </CardDescription>
      </CardContent>
      <CardContent extra>
        <a>
          <Icon name="star full" />
          {props.rating.rate}
        </a>
      </CardContent>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          gap: "20px",
          padding: "10px",
        }}
      >
        <ConfirmExampleConfirm
          onConfirm={() => {
            props.removeProduct(props.id);
          }}
        />
        <Button
          style={{ backgroundColor: "seagreen", color: "white" }}
          secondary
        >
          Update
        </Button>
      </div>
    </Card>
  );
};

export default CardExampleCard;
