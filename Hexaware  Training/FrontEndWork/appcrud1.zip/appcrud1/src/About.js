
import React from 'react';

const About = () => {
    return (
        <div>
            <h1>About Us</h1>
            <p>We are a team of innovators dedicated to providing cutting-edge solutions for your needs.</p>
        </div>
    );
};

export default About;