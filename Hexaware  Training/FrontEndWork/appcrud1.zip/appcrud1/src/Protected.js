import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
 
const Protected = ({ Component }) => {
  const navigate = useNavigate();
 
  useEffect(() => {
    const flag = sessionStorage.getItem("flag");
    if (flag !== "true") {
      navigate("/signin"); // Correct the path here if necessary
    }
  }, [navigate]);
 
  return (
    <>
     <Component />
    </>
  );
};
 
export default Protected;