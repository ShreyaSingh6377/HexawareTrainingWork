// // import "./App.css"
// // const Login=()=>
// // {
 
 
// // return(<>
// //   <div className="cont">
   
// //    <input type="text" placeholder="enter ur id"/><br/>
// //    <input type="text" placeholder="enter ur Password"/><br/>
 
// //   <button> Sign in </button>
 
// //   </div>
 
 
 
// // </>)
 
 
// // }
// // export default Login

// import { useState } from "react"
// import "./App.css"
// import { useNavigate } from "react-router-dom"
// const Login=()=>
// {
//     let nav=useNavigate()
//     let [id,setId]=useState()
//     let [pass,setPass]=useState()
 
//       const sign=()=>
//       {
//         if(id==="mom" && pass==="dad")
//         {
 
//           nav("/welcome",{state:{id}})
//            // alert("welome")
//         }
//         else{
//             alert("not welcome")
//         }
//       }
 
// return(<>
//   <div className="cont">
   
//    <input type="text" placeholder="enter ur id" onChange={(e)=>setId(e.target.value)}/><br/>
//    <input type="text" placeholder="enter ur Password" onChange={(e)=>setPass(e.target.value)}/><br/>
 
//   <button onClick={sign}> Sign in </button>
 
//   </div>
 
 
 
// </>)
 
 
// }
// export default Login

import { useState } from "react"
import "./App.css"
import { useNavigate } from "react-router-dom"
const Login=()=>
{
    let nav=useNavigate()
    let [id,setId]=useState()
    let [pass,setPass]=useState()
 
      const sign=()=>
      {
        if(id==="mom" && pass==="dad")
        {
 
          
           //alert("welome")
           //nav("/welcome",{state:{id,pass}})

          /*localStorage.setItem("id", id);
          localStorage.setItem("password", pass);     
          nav("/welcome1");*/

          sessionStorage.setItem("flag",true);
          nav("/pay");
        }
        else{
            //alert("not welcome")
            nav("/notwelcome", { state: { id, pass } });
        }
      }
 
return(<>
  <div className="cont">
   
   <input type="text" placeholder="enter ur id" onChange={(e)=>setId(e.target.value)}/><br/>
   <input type="text" placeholder="enter ur Password" onChange={(e)=>setPass(e.target.value)}/><br/>
 
  <button onClick={sign}> Sign in </button>
 
  </div>
 
 
 
</>)
 
 
}
export default Login
 