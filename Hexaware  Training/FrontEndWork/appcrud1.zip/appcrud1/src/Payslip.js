// import { useState } from "react"
 
// const Payslip=()=>
// {
// let [name,setName]=useState()
// let [salary,setSalary]=useState()
 
 
 
 
// return(<>
 
// <div className="cont">
   
//    <input type="text" placeholder="enter ur Name" onChange={(e)=>setName(e.target.value)}/><br/>
   
//    <input type="text" placeholder="enter ur Salary" onChange={(e)=>setSalary(e.target.value)}/><br/>
 
//   <button > show Payslip </button>
 
//   </div>
 
// </>)
 
 
// }
// export default Payslip
//above is mam's code

import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Payslip = () => {
  let [name, setName] = useState("");
  let [salary, setSalary] = useState("");
  let nav = useNavigate();

  const showPayslip = () => {
    if (name && salary) {
      nav("/invoice", { state: { name, salary: parseFloat(salary) } });
    } else {
      alert("Please enter both name and salary.");
    }
  };

  return (
    <>
      <div className="cont">
        <input
          type="text"
          placeholder="Enter your Name"
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        <input
          type="number"
          placeholder="Enter your Salary"
          onChange={(e) => setSalary(e.target.value)}
        />
        <br />
        <button onClick={showPayslip}>Show Payslip</button>
      </div>
    </>
  );
};

export default Payslip;
