import React from 'react';
import Routing from './Routing'; // Import the Routing component
import Menu from './Menu';
import {Link} from "react-router-dom";
import  { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// function App() {
//   let[users,setUsers]=useState(["asha","pooja","kavita","jatin"])
//   return (
//     <div>
//       <Routing /> {/* Add the Routing component here */}
//     <Menu/>
//     <Link to="./signin"><button>Sign in</button></Link>
//     <ul>
//        <Link to="/user/asha"><li> Asha</li></Link>
//        <Link to="/user/pooja"> <li> Pooja</li></Link>
   
//     </ul>
//     </div>
//   );
// }

// export default App;

//dynamic routing
function App() {
 
  let [users,setUsers]=useState(["asha","pooja","kavita","deepa","jatin","ajay"])
 
 
  return (
    <div>
 
      <Routing/>
      <Menu/>
 
 
     {
      users.map((temp)=>
      <Link to={`/user/${temp}`}> <h2> {temp}</h2></Link>
      )
 
     }
 
    <ul>
       <Link to="/user/asha"><li> Asha</li></Link>
       <Link to="/user/pooja"> <li> Pooja</li></Link>
   
    </ul>
 
 
 
     
    </div>
  );
}
 
export default App;