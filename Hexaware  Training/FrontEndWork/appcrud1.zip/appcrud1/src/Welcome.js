import { useLocation } from "react-router-dom"
 
const Welcome=()=>
{
 
let data= useLocation()
let {id,pass}=data.state;
 
return(<>
 
 
<h1> WELCOME{id} {pass}</h1>
 
 
</>)
 
 
}
export default Welcome