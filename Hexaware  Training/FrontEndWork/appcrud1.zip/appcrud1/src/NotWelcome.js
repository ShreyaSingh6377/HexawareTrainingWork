import { useLocation } from "react-router-dom";

const NotWelcome = () => {
  let data = useLocation();
  let { id, pass } = data.state;

  return (
    <>
      <h1>Sorry, {id}. Your login credentials ({id}, {pass}) are incorrect.</h1>
    </>
  );
};

export default NotWelcome;
