import { useParams } from "react-router-dom"
 
const User=()=>
{
 
 
   let {nm}= useParams()
 
 
    return(<>
 
    <h1> WELCOME   {nm} </h1>
   
   
    </>)
}
export default User
 