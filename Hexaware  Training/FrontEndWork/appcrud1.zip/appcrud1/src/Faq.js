
import React from 'react';

const Faq = () => {
    return (
        <div>
            <h1>Frequently Asked Questions</h1>
            <div>
                <strong>What is our return policy?</strong>
                <p>You can return any item within 30 days of purchase for a full refund.</p>
            </div>
        </div>
    );
};

export default Faq;