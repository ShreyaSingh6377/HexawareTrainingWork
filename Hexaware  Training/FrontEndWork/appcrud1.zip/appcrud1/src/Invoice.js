import { useLocation } from "react-router-dom";

const Invoice = () => {
  const data = useLocation();
  const { name, salary } = data.state;
  const bonus = salary * 0.05;
  const totalSalary = parseFloat(salary) + bonus;

  return (
    <>
      <h1>Invoice</h1>
      <p><strong>Name:</strong> {name}</p>
      <p><strong>Salary:</strong> {salary}</p>
      <p><strong>Bonus (5%):</strong> {bonus.toFixed(2)}</p>
      <p><strong>Total Salary:</strong> {totalSalary.toFixed(2)}</p>
    </>
  );
};

export default Invoice;
