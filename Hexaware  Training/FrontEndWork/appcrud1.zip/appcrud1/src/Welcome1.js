// const Welcome1 = () => {
//     const id = localStorage.getItem("id");
//     const password = localStorage.getItem("password");
  
//     return (
//       <>
//         <h1>Welcome!</h1>
//         <p><strong>ID:</strong> {id}</p>
//         <p><strong>Password:</strong> {password}</p>
//       </>
//     );
//   };
  
//   export default Welcome1;
  //without useeffect

  import { useEffect, useState } from "react";

const Welcome1 = () => {
    const [id, setId] = useState("");
    const [pwd, setPwd] = useState("");

    useEffect(() => {
        const id = localStorage.getItem("id");
        const pwd = localStorage.getItem("password");
        setId(id);
        setPwd(pwd);
    }, []);

    return (
        <div>
            <h1>Welcome.</h1>
            <h2>Id: {id} Password: {pwd}</h2>
        </div>
    );
};

export default Welcome1;