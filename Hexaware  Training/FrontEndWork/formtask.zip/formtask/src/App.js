import logo from './logo.svg';
import './App.css';
import FeedbackForm from './FeedbackForm';
function App() {
  return (
    <div>
      <FeedbackForm />
    </div>
  );
}

export default App;
