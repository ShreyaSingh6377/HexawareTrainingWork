import React, { useState } from 'react';
import { Form, Button, Message, Radio, Dropdown, TextArea } from 'semantic-ui-react';

function FeedbackForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [reenterPassword, setReenterPassword] = useState('');
  const [gender, setGender] = useState('');
  const [subject, setSubject] = useState([]);
  const [skills, setSkills] = useState('');
  const [grade, setGrade] = useState('');
  const [qualification, setQualification] = useState('');
  const [hobby, setHobby] = useState('');
  const [feedback, setFeedback] = useState('');
  const [experience, setExperience] = useState(5);

  const [nameError, setNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [reenterPasswordError, setReenterPasswordError] = useState('');
  const [genderError, setGenderError] = useState('');
  const [subjectError, setSubjectError] = useState('');
  const [skillsError, setSkillsError] = useState('');
  const [gradeError, setGradeError] = useState('');
  const [qualificationError, setQualificationError] = useState('');
  const [hobbyError, setHobbyError] = useState('');
  const [feedbackError, setFeedbackError] = useState('');

  const handleExperienceChange = (e) => {
    setExperience(e.target.value);
  };

  const handleNameChange = (e) => {
    const value = e.target.value;
    setName(value);

    const regex = /\d/;
    if (regex.test(value)) {
      setNameError('Name can\'t have numbers');
    } else {
      setNameError('');
    }
  };

  const handleEmailChange = (e) => {
    const value = e.target.value;
    setEmail(value);

    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(value)) {
      setEmailError('Please enter a valid email');
    } else {
      setEmailError('');
    }
  };

  const handlePasswordChange = (e) => {
    const value = e.target.value;
    setPassword(value);

    if (value.length < 6) {
      setPasswordError('Password must be at least 6 characters long');
    } else {
      setPasswordError('');
    }
  };

  const handleReenterPasswordChange = (e) => {
    const value = e.target.value;
    setReenterPassword(value);

    if (value !== password) {
      setReenterPasswordError('Passwords do not match');
    } else {
      setReenterPasswordError('');
    }
  };

  const handleGenderChange = (e, { value }) => {
    setGender(value);
    setGenderError('');
  };

  const handleSubjectChange = (e, { value }) => {
    setSubject(value);
    setSubjectError('');
  };

  const handleSkillsChange = (e) => {
    setSkills(e.target.value);
    setSkillsError('');
  };

  const handleGradeChange = (e, { value }) => {
    setGrade(value);
    setGradeError('');
  };

  const handleQualificationChange = (e, { value }) => {
    setQualification(value);
    setQualificationError('');
  };

  const handleHobbyChange = (e) => {
    setHobby(e.target.value);
    setHobbyError('');
  };

  const handleFeedbackChange = (e) => {
    setFeedback(e.target.value);
    setFeedbackError('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (
      !nameError &&
      !emailError &&
      !passwordError &&
      !reenterPasswordError &&
      !genderError &&
      !subjectError &&
      !skillsError &&
      !gradeError &&
      !qualificationError &&
      !hobbyError &&
      !feedbackError &&
      name !== '' &&
      email !== '' &&
      password !== '' &&
      reenterPassword !== '' &&
      gender !== '' &&
      subject.length > 0 &&
      skills !== '' &&
      grade !== '' &&
      qualification !== '' &&
      hobby !== '' &&
      feedback !== ''
    ) {
      alert(`Form submitted successfully!`);
    } else {
      alert('Please fill out the form correctly.');
    }
  };

  const genderOptions = [
    { key: 'male', text: 'Male', value: 'Male' },
    { key: 'female', text: 'Female', value: 'Female' },
    { key: 'other', text: 'Other', value: 'Other' },
  ];

  const subjectOptions = [
    { key: 'english', text: 'English', value: 'English' },
    { key: 'hindi', text: 'Hindi', value: 'Hindi' },
    { key: 'maths', text: 'Maths', value: 'Maths' },
    { key: 'science', text: 'Science', value: 'Science' },
  ];

  const gradeOptions = [
    { key: 'a+', text: 'A+', value: 'A+' },
    { key: 'a', text: 'A', value: 'A' },
    { key: 'b+', text: 'B+', value: 'B+' },
    { key: 'b', text: 'B', value: 'B' },
    { key: 'c+', text: 'C+', value: 'C+' },
    { key: 'c', text: 'C', value: 'C' },
    { key: 'd+', text: 'D+', value: 'D+' },
    { key: 'd', text: 'D', value: 'D' },
  ];

  const qualificationOptions = [
    { key: 'highSchool', text: 'High School', value: 'High School' },
    { key: 'secondary', text: 'Secondary', value: 'Secondary' },
    { key: 'undergraduate', text: 'Undergraduate', value: 'Undergraduate' },
    { key: 'graduate', text: 'Graduate', value: 'Graduate' },
  ];

  return (
    <Form onSubmit={handleSubmit} error={!!nameError || !!emailError || !!passwordError || !!reenterPasswordError || !!genderError || !!subjectError || !!skillsError || !!gradeError || !!qualificationError || !!hobbyError || !!feedbackError}>
      <Form.Field>
        <label htmlFor="name">Name</label>
        <input
          type="text"
          id="name"
          name="name"
          value={name}
          onChange={handleNameChange}
          required
        />
      </Form.Field>
      {nameError && (
        <Message error>
          <Message.Header>{nameError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value={email}
          onChange={handleEmailChange}
          required
        />
      </Form.Field>
      {emailError && (
        <Message error>
          <Message.Header>{emailError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          value={password}
          onChange={handlePasswordChange}
          required
        />
      </Form.Field>
      {passwordError && (
        <Message error>
          <Message.Header>{passwordError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="reenterPassword">Re-enter Password</label>
        <input
          type="password"
          id="reenterPassword"
          name="reenterPassword"
          value={reenterPassword}
          onChange={handleReenterPasswordChange}
          required
        />
      </Form.Field>
      {reenterPasswordError && (
        <Message error>
          <Message.Header>{reenterPasswordError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="gender">Gender</label>
        <Radio
          label="Male"
          value="Male"
          checked={gender === 'Male'}
          onChange={handleGenderChange}
        />
        <Radio
          label="Female"
          value="Female"
          checked={gender === 'Female'}
          onChange={handleGenderChange}
        />
        <Radio
          label="Other"
          value="Other"
          checked={gender === 'Other'}
          onChange={handleGenderChange}
        />
      </Form.Field>
      {genderError && (
        <Message error>
          <Message.Header>{genderError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="subject">Subject</label>
        <Dropdown
          placeholder="Select Subject"
          fluid
          multiple
          selection
          options={subjectOptions}
          value={subject}
          onChange={handleSubjectChange}
        />
      </Form.Field>
      {subjectError && (
        <Message error>
          <Message.Header>{subjectError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="skills">Skills</label>
        <input
          type="text"
          id="skills"
          name="skills"
          value={skills}
          onChange={handleSkillsChange}
        />
      </Form.Field>
      {skillsError && (
        <Message error>
          <Message.Header>{skillsError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="grade">Grade</label>
        <Dropdown
          placeholder="Select Grade"
          fluid
          selection
          options={gradeOptions}
          value={grade}
          onChange={handleGradeChange}
        />
      </Form.Field>
      {gradeError && (
        <Message error>
          <Message.Header>{gradeError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="qualification">Qualification</label>
        <Dropdown
          placeholder="Select Qualification"
          fluid
          selection
          options={qualificationOptions}
          value={qualification}
          onChange={handleQualificationChange}
        />
      </Form.Field>
      {qualificationError && (
        <Message error>
          <Message.Header>{qualificationError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="hobby">Hobby</label>
        <input
          type="text"
          id="hobby"
          name="hobby"
          value={hobby}
          onChange={handleHobbyChange}
        />
      </Form.Field>
      {hobbyError && (
        <Message error>
          <Message.Header>{hobbyError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="feedback">Feedback</label>
        <TextArea
          id="feedback"
          name="feedback"
          value={feedback}
          onChange={handleFeedbackChange}
        />
      </Form.Field>
      {feedbackError && (
        <Message error>
          <Message.Header>{feedbackError}</Message.Header>
        </Message>
      )}

      <Form.Field>
        <label htmlFor="experience">Your Experience</label>
        <input
          type="range"
          id="experience"
          name="experience"
          min="0"
          max="10"
          step="1"
          value={experience}
          onChange={handleExperienceChange}
        />
        <p>Experience Level: {experience}</p>
      </Form.Field>

      <Button
        type="submit"
        disabled={nameError || emailError || passwordError || reenterPasswordError || genderError || subjectError || skillsError || gradeError || qualificationError || hobbyError || feedbackError || name === '' || email === '' || password === '' || reenterPassword === '' || gender === '' || subject.length === 0 || skills === '' || grade === '' || qualification === '' || hobby === '' || feedback === ''}
        primary
      >
        Submit
      </Button>
    </Form>
  );
}

export default FeedbackForm;
